//
//  ViewController.m
//  App1
//
//  Created by Batu on 16/11/9.
//  Copyright © 2016年 King. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    button.backgroundColor = [UIColor redColor];
    [button setTitle:@"跳转到2APP" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

-(void)buttonAction:(UIButton *)tb{
    
    
    NSURL *url = [NSURL URLWithString:@"App2:"];
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.0) {
        // iOS 10 code
        [[UIApplication sharedApplication] openURL:url options:@{UIApplicationOpenURLOptionsOpenInPlaceKey:@"1"} completionHandler:^(BOOL success) {
            // 回调
            if (!success) {
                NSLog(@"success");
            }
        }];
    }
    else {
        // < iOS 9 code
        BOOL result = [[UIApplication sharedApplication] canOpenURL:url];
        
        if (result == YES) {
            
            [[UIApplication sharedApplication] openURL:url];
            
        }
        
    }
  
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
