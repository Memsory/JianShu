//
//  SecondViewController.h
//  APP2
//
//  Created by Batu on 16/11/9.
//  Copyright © 2016年 King. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
